<?php
$lang['welcome'] = "ہماری ویب سائٹ پر خوش آمدید";
$lang['about_us'] = "ہمارے بارے میں";
