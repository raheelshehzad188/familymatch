<h2>Add Ethnicity</h2>
<form method="post">
    <input type="text" name="name" class="form-control" placeholder="Ethnicity name" required>
    <br>
    <button type="submit" class="btn btn-success">Add</button>
</form>
