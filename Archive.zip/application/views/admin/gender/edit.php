<h2>Edit <?= $label ?></h2>
<form method="post">
    <input type="text" name="name" class="form-control" value="<?= $ethnicity['name'] ?>" required>
    <br>
    <button type="submit" class="btn btn-primary">Update</button>
</form>
