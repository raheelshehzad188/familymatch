<?php
$lang['welcome'] = "Welcome to our website";
$lang['about_us'] = "About Us";
