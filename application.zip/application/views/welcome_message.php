<h1><?php echo $this->lang->line('welcome'); ?></h1>
<a href="<?php echo base_url('languageSwitcher/switchLanguage/english'); ?>">English</a> |
<a href="<?php echo base_url('languageSwitcher/switchLanguage/urdu'); ?>">Urdu</a>
