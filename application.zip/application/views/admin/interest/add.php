<h2>Add <?= $thi->sing ?></h2>
<form method="post" enctype="multipart/form-data">
    <input type="text" name="title" class="form-control" placeholder="Title" required><br>
    <input type="file" name="image" class="form-control"><br>
    <button type="submit" class="btn btn-success">Add</button>
</form>
